
import requests
from datetime import datetime, timedelta
import time

# 🔐 Токен и чат-id будут заданы через переменные среды на Render
import os
BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
TVL_THRESHOLD = 500_000

def get_trending_protocols():
    url = "https://api.llama.fi/protocols"
    try:
        response = requests.get(url, timeout=10)
        data = response.json()
    except Exception as e:
        print(f"Ошибка при получении данных: {e}")
        return []

    trending = []
    now = datetime.utcnow()
    three_days_ago = now - timedelta(days=3)

    for protocol in data:
        try:
            added = datetime.strptime(protocol.get("addTimestamp", ""), "%Y-%m-%dT%H:%M:%S.%fZ")
        except:
            continue

        if added > three_days_ago and protocol.get("tvl", 0) > TVL_THRESHOLD:
            trending.append({
                "name": protocol["name"],
                "url": f'https://defillama.com/protocol/{protocol["slug"]}',
                "tvl": int(protocol["tvl"])
            })
    return trending

def format_report(protocols):
    if not protocols:
        return "⚠️ Нет новых протоколов с TVL > $500K за последние 3 дня."

    msg = "*🚀 Новые DeFi проекты:*

"
    for p in protocols:
        msg += f"🔹 [{p['name']}]({p['url']}) — TVL: ${p['tvl']:,}
"
    msg += "\n_Обновлено: " + datetime.now().strftime('%Y-%m-%d %H:%M') + "_"
    return msg

def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": text, "parse_mode": "Markdown"}
    try:
        response = requests.post(url, json=payload)
        print("✅ Уведомление отправлено.")
    except Exception as e:
        print(f"Ошибка при отправке: {e}")

# Тестовое сообщение при запуске
send_telegram_message("✅ Бот запущен и работает! Ожидаю 10:00 и 18:00.")

# Цикл ожидания
while True:
    now = datetime.utcnow() + timedelta(hours=3)
    print(f"⏱ Проверка... сейчас {now.strftime('%H:%M:%S')}")

    if now.hour in [10, 18] and now.minute == 0:
        print("📡 Время отправки! Получаю данные...")
        report = format_report(get_trending_protocols())
        send_telegram_message(report)
        time.sleep(60)
    
    time.sleep(30)
